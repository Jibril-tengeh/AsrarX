import React, { useState, useEffect } from 'react';
import { Calculator, ArrowLeft, RefreshCw, Copy, Check, ChevronDown, ChevronUp, History, Save, Trash2, X, Database, Wifi, HelpCircle } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useLanguage } from '../../../contexts/LanguageContext';
import { ToolInfoTooltip } from '../../../components/ToolInfoTooltip';
import { motion, AnimatePresence } from 'motion/react';

// Simplified Abjad table mapping (Standard/Eastern)
const abjadMashriqi: Record<string, number> = {
  'ا': 1, 'أ': 1, 'إ': 1, 'آ': 1, 'ء': 1,
  'ب': 2, 'ج': 3, 'د': 4, 'ه': 5, 'ة': 5,
  'و': 6, 'ؤ': 6, 'ز': 7, 'ح': 8, 'ط': 9,
  'ي': 10, 'ى': 10, 'ئ': 10, 'ك': 20, 'ل': 30,
  'م': 40, 'ن': 50, 'س': 60, 'ع': 70, 'ف': 80,
  'ص': 90, 'ق': 100, 'ر': 200, 'ش': 300, 'ت': 400,
  'ث': 500, 'خ': 600, 'ذ': 700, 'ض': 800, 'ظ': 900,
  'غ': 1000
};

// Maghribi variant
const abjadMaghribi: Record<string, number> = {
  ...abjadMashriqi,
  'س': 300, 'ش': 1000, 'ص': 60, 'ض': 90, 'ظ': 800, 'غ': 900
};

const localDict = {
  fr: {
    cacheLocal: "Cache local (Mode Offline actif)",
    syncLocal: "Synchronisé localement (Offline-first)",
    enterArabic: "Entrez le texte en Arabe",
    words: "Mots",
    letters: "Lettres",
    numericValues: "Valeurs Numériques (Abjad)",
    howToInterpret: "Comment interpréter ces résultats ?",
    interpret: "Interpréter"
  },
  en: {
    cacheLocal: "Local cache (Offline Mode active)",
    syncLocal: "Locally synchronized (Offline-first)",
    enterArabic: "Enter text in Arabic",
    words: "Words",
    letters: "Letters",
    numericValues: "Numerical Values (Abjad)",
    howToInterpret: "How to interpret these results?",
    interpret: "Interpret"
  },
  ha: {
    cacheLocal: "Ma'ajiyar gida (Yanayin Offline yana aiki)",
    syncLocal: "An daidaita na gida (Offline-farko)",
    enterArabic: "Shigar da rubutu cikin Harshen Larabci",
    words: "Kalmomi",
    letters: "Haruffa",
    numericValues: "Darajojin Lambobi (Abjad)",
    howToInterpret: "Yadda za a fassara waɗannan sakamakon?",
    interpret: "Fassara"
  }
};

export const AbjadCalculator: React.FC = () => {
  const { t, language } = useLanguage();
  const dict = localDict[(language as 'fr' | 'en' | 'ha') || 'fr'] || localDict.fr;
  const [text, setText] = useState('');
  const [copied, setCopied] = useState(false);
  const [showWords, setShowWords] = useState(false);
  const [showLetters, setShowLetters] = useState(false);
  
  const [history, setHistory] = useState<{ id: string; text: string; mashriqi: number; maghribi: number; timestamp: number }[]>([]);
  const [showHistory, setShowHistory] = useState(false);
  const [showAbjadInfoModal, setShowAbjadInfoModal] = useState(false);
  const [isUsingCache, setIsUsingCache] = useState(true);

  // Load abjad state and history on mount
  useEffect(() => {
    try {
      const savedText = localStorage.getItem('abjad_draft_text');
      if (savedText) setText(savedText);
      const savedShowWords = localStorage.getItem('abjad_show_words');
      if (savedShowWords) setShowWords(savedShowWords === 'true');
      const savedShowLetters = localStorage.getItem('abjad_show_letters');
      if (savedShowLetters) setShowLetters(savedShowLetters === 'true');
    } catch (e) {
      console.warn("Failed to load Abjad state", e);
    }

    const saved = localStorage.getItem('abjad_history');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) setHistory(parsed);
      } catch (e) {}
    }
    setIsUsingCache(!navigator.onLine);
  }, []);

  // Save text draft to localStorage on change
  useEffect(() => {
    try {
      localStorage.setItem('abjad_draft_text', text);
    } catch (e) {}
  }, [text]);

  // Save configurations on change
  useEffect(() => {
    try {
      localStorage.setItem('abjad_show_words', String(showWords));
    } catch (e) {}
  }, [showWords]);

  useEffect(() => {
    try {
      localStorage.setItem('abjad_show_letters', String(showLetters));
    } catch (e) {}
  }, [showLetters]);

  const saveToHistory = () => {
    if (!text.trim() || totalMashriqi === 0) return;
    const newItem = {
      id: Date.now().toString(),
      text: text.trim(),
      mashriqi: totalMashriqi,
      maghribi: totalMaghribi,
      timestamp: Date.now(),
    };
    const newHistory = [newItem, ...history.filter(h => h.text !== newItem.text)].slice(0, 20);
    setHistory(newHistory);
    localStorage.setItem('abjad_history', JSON.stringify(newHistory));
  };

  const clearHistory = () => {
    setHistory([]);
    localStorage.removeItem('abjad_history');
  };

  const calculateAbjad = (input: string) => {
    let totalMashriqi = 0;
    let totalMaghribi = 0;
    
    // For breakdown, we keep both values
    const details: { char: string; valMashriqi: number; valMaghribi: number }[] = [];
    const wordsDetails: { word: string; valMashriqi: number; valMaghribi: number }[] = [];
    
    const rawWords = input.trim().split(/\s+/).filter(w => w.length > 0);
    const words = rawWords.length;
    let letterCount = 0;
    
    for (const word of rawWords) {
      let wordMashriqi = 0;
      let wordMaghribi = 0;
      
      for (const char of word) {
        const vMash = abjadMashriqi[char] || 0;
        const vMagh = abjadMaghribi[char] || 0;
        
        wordMashriqi += vMash;
        wordMaghribi += vMagh;
        totalMashriqi += vMash;
        totalMaghribi += vMagh;
        
        if (vMash || vMagh) {
          letterCount++;
        }
        details.push({ char, valMashriqi: vMash, valMaghribi: vMagh });
      }
      wordsDetails.push({ word, valMashriqi: wordMashriqi, valMaghribi: wordMaghribi });
    }

    return { totalMashriqi, totalMaghribi, details, wordsDetails, words, letterCount };
  };

  const { totalMashriqi, totalMaghribi, details, wordsDetails, words, letterCount } = calculateAbjad(text);

  const handleCopy = (val: number) => {
    navigator.clipboard.writeText(val.toString());
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="max-w-2xl mx-auto p-4 sm:p-6 lg:p-8 safe-area-pt pb-24">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-4">
          <Link 
            to="/tools" 
            className="p-2 -ml-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-500 transition-colors"
          >
            <ArrowLeft size={24} />
          </Link>
          <div>
            <h1 className="text-xl sm:text-2xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
              <Calculator className="text-blue-500" />
              Abjad
            </h1>
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">{t("tools.abjad.subtitle")}</p>
            {isUsingCache ? (
              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-50 text-amber-700 dark:bg-amber-950/30 dark:text-amber-400 border border-amber-100 dark:border-amber-900/30 mt-2">
                <Database size={11} className="animate-pulse" />
                <span>{dict.cacheLocal}</span>
              </div>
            ) : (
              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 dark:bg-emerald-950/30 dark:text-emerald-400 border border-emerald-100 dark:border-emerald-900/30 mt-2">
                <Wifi size={11} />
                <span>{dict.syncLocal}</span>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="space-y-6">
        {/* Input Card */}
        <div className="bg-white dark:bg-gray-800 rounded-3xl p-4 sm:p-5 shadow-sm border border-gray-100 dark:border-gray-700">
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            {dict.enterArabic}
          </label>
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder={t("tools.abjad.inputPlaceholder")}
            dir="rtl"
            rows={4}
            className="w-full bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-2xl p-4 text-xl sm:text-2xl text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none font-arabic"
          />
          <div className="flex justify-between items-center mt-3">
            <div className="flex gap-4 text-xs font-medium text-gray-500 dark:text-gray-400">
              <span>{dict.words}: <strong className="text-gray-700 dark:text-gray-300">{words}</strong></span>
              <span>{dict.letters}: <strong className="text-gray-700 dark:text-gray-300">{letterCount}</strong></span>
            </div>
            <div className="flex gap-2">
              <button
                onClick={saveToHistory}
                disabled={!text.trim() || totalMashriqi === 0}
                className="px-4 py-2 text-sm text-blue-600 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300 transition-colors flex items-center gap-1.5 disabled:opacity-50"
              >
                <Save size={14} />
                <span className="hidden sm:inline">{t("tools.abjad.save")}</span>
              </button>
              <button
                onClick={() => setText('')}
                className="px-4 py-2 text-sm text-gray-500 hover:text-gray-700 dark:hover:text-gray-300 transition-colors flex items-center gap-1.5"
              >
                <RefreshCw size={14} />
                <span className="hidden sm:inline">{t("tools.abjad.clear")}</span>
              </button>
            </div>
          </div>
        </div>

        <ToolInfoTooltip toolId="abjad" />

        <div className="flex justify-between items-center px-1">
          <h2 className="text-sm font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider flex items-center gap-1.5">
            {dict.numericValues}
          </h2>
          <button 
            onClick={() => setShowAbjadInfoModal(true)}
            className="text-gray-400 hover:text-blue-500 dark:hover:text-blue-400 p-1.5 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors flex items-center gap-1 cursor-pointer"
            title={dict.howToInterpret}
          >
            <HelpCircle size={16} />
            <span className="text-xs font-semibold">{dict.interpret}</span>
          </button>
        </div>

        {/* Result Card */}
        <motion.div 
          className={`grid grid-cols-2 gap-3 sm:gap-4 transition-all duration-300 ${totalMashriqi > 0 ? 'opacity-100 translate-y-0' : 'opacity-50'}`}
        >
          {/* Mashriqi (Orientale) */}
          <div className="bg-gradient-to-br from-blue-600 to-indigo-700 rounded-3xl p-4 sm:p-5 text-white shadow-lg relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-white opacity-5 rounded-full -translate-y-1/2 translate-x-1/2 blur-2xl"></div>
            <div className="relative z-10 flex flex-col items-center text-center">
              <span className="text-blue-100 text-xs sm:text-sm font-medium uppercase tracking-widest mb-2">{t("tools.abjad.mashriq")}</span>
              <div className="text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight mb-3 sm:mb-4 tabular-nums">
                {totalMashriqi}
              </div>
              {totalMashriqi > 0 && (
                <button
                  onClick={() => handleCopy(totalMashriqi)}
                  className="flex items-center justify-center gap-1.5 sm:gap-2 px-3 sm:px-4 py-1.5 sm:py-2 bg-white/10 hover:bg-white/20 rounded-full backdrop-blur-sm transition-colors text-xs sm:text-sm font-medium w-full sm:w-auto"
                >
                  {copied ? <Check size={16} className="text-emerald-300" /> : <Copy size={16} />}
                  {copied ? t('tools.abjad.copied') : t('tools.abjad.copy')}
                </button>
              )}
            </div>
          </div>

          {/* Maghribi (Occidentale) */}
          <div className="bg-gradient-to-br from-emerald-600 to-teal-700 rounded-3xl p-4 sm:p-5 text-white shadow-lg relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-white opacity-5 rounded-full -translate-y-1/2 translate-x-1/2 blur-2xl"></div>
            <div className="relative z-10 flex flex-col items-center text-center">
              <span className="text-emerald-100 text-xs sm:text-sm font-medium uppercase tracking-widest mb-2">{t("tools.abjad.maghribi")}</span>
              <div className="text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight mb-3 sm:mb-4 tabular-nums">
                {totalMaghribi}
              </div>
              {totalMaghribi > 0 && (
                <button
                  onClick={() => handleCopy(totalMaghribi)}
                  className="flex items-center justify-center gap-1.5 sm:gap-2 px-3 sm:px-4 py-1.5 sm:py-2 bg-white/10 hover:bg-white/20 rounded-full backdrop-blur-sm transition-colors text-xs sm:text-sm font-medium w-full sm:w-auto"
                >
                  {copied ? <Check size={16} className="text-green-300" /> : <Copy size={16} />}
                  {copied ? t('tools.abjad.copied') : t('tools.abjad.copy')}
                </button>
              )}
            </div>
          </div>
        </motion.div>

        {/* Detailed Breakdown */}
        {details.length > 0 && (
          <div className="space-y-4 mt-8">
            {/* By Words */}
            <div className="bg-white dark:bg-gray-800 rounded-3xl overflow-hidden shadow-sm border border-gray-100 dark:border-gray-700">
              <button 
                onClick={() => setShowWords(!showWords)}
                className="w-full flex items-center justify-between p-4 sm:p-5 text-left hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors"
              >
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white">{t("tools.abjad.adadByWords")}</h3>
                {showWords ? <ChevronUp className="text-gray-400" /> : <ChevronDown className="text-gray-400" />}
              </button>
              
              <AnimatePresence>
                {showWords && (
                  <motion.div 
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="overflow-hidden"
                  >
                    <div className="p-4 sm:p-5 pt-0 flex flex-wrap gap-3 justify-end border-t border-gray-50 dark:border-gray-700/50" dir="rtl">
                      {wordsDetails.map((item, i) => (
                        <div key={i} className="flex flex-col items-center bg-gray-50 dark:bg-gray-700/50 rounded-xl p-3 min-w-[5rem] border border-gray-100 dark:border-gray-600 shadow-sm">
                          <span className="text-xl font-bold text-gray-900 dark:text-white mb-2 font-arabic">{item.word}</span>
                          <div className="flex gap-3 text-xs w-full justify-center">
                            <div className="flex flex-col items-center">
                              <span className="text-gray-400 text-[10px]">{t("tools.abjad.oriental")}</span>
                              <span className="text-blue-600 dark:text-blue-400 font-bold">{item.valMashriqi}</span>
                            </div>
                            <div className="flex flex-col items-center">
                              <span className="text-gray-400 text-[10px]">{t("tools.abjad.occidental")}</span>
                              <span className="text-emerald-600 dark:text-emerald-400 font-bold">{item.valMaghribi}</span>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* By Letters */}
            <div className="bg-white dark:bg-gray-800 rounded-3xl overflow-hidden shadow-sm border border-gray-100 dark:border-gray-700">
              <button 
                onClick={() => setShowLetters(!showLetters)}
                className="w-full flex items-center justify-between p-4 sm:p-5 text-left hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors"
              >
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white">{t("tools.abjad.adadByLetters")}</h3>
                {showLetters ? <ChevronUp className="text-gray-400" /> : <ChevronDown className="text-gray-400" />}
              </button>
              
              <AnimatePresence>
                {showLetters && (
                  <motion.div 
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="overflow-hidden"
                  >
                    <div className="p-4 sm:p-5 pt-0 flex flex-wrap gap-2 justify-end border-t border-gray-50 dark:border-gray-700/50" dir="rtl">
                      {details.map((item, i) => (
                        <div key={i} className={`flex flex-col items-center rounded-lg p-2 min-w-[3.5rem] border ${!item.valMashriqi && !item.valMaghribi ? 'bg-gray-100 dark:bg-gray-800 border-transparent opacity-50' : 'bg-gray-50 dark:bg-gray-700/50 border-gray-100 dark:border-gray-600'}`}>
                          <span className="text-lg font-bold text-gray-900 dark:text-white mb-1 font-arabic">{item.char}</span>
                          <div className="flex gap-2 text-[10px] w-full justify-center">
                            <span className="text-blue-600 dark:text-blue-400 font-bold" title="Oriental">{item.valMashriqi || '-'}</span>
                            <span className="text-emerald-600 dark:text-emerald-400 font-bold" title="Occidental">{item.valMaghribi || '-'}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        )}

        {/* Historique Toggle Button Under Cards */}
        <div className="flex justify-center mt-2">
          <button 
            onClick={() => setShowHistory(!showHistory)}
            className={`flex items-center gap-2 px-6 py-3 rounded-2xl text-sm font-bold transition-all border shadow-sm ${showHistory ? 'bg-blue-50 border-blue-200 text-blue-700 dark:bg-blue-900/30 dark:border-blue-800 dark:text-blue-400' : 'bg-white border-gray-200 text-gray-700 hover:bg-gray-50 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-300 dark:hover:bg-gray-700 hover:scale-105 active:scale-95'}`}
          >
            <History size={20} className={showHistory ? 'text-blue-600 dark:text-blue-400' : 'text-gray-500'} />
            <span>{t("tools.abjad.historyTitle")}</span>
            {showHistory ? <ChevronUp size={18} className="text-gray-400 ml-2" /> : <ChevronDown size={18} className="text-gray-400 ml-2" />}
          </button>
        </div>

        <AnimatePresence>
          {showHistory && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="overflow-hidden"
            >
              <div className="bg-white dark:bg-gray-800 p-4 sm:p-5 rounded-3xl border border-gray-100 dark:border-gray-700 shadow-sm mt-4">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-bold text-gray-900 dark:text-white flex items-center gap-2">
                    <History size={18} className="text-blue-500" /> Historique
                  </h3>
                  {history.length > 0 && (
                    <button onClick={clearHistory} className="text-sm text-red-500 hover:text-red-600 flex items-center gap-1">
                      <Trash2 size={14} /> {t("common.clear")}
                    </button>
                  )}
                </div>
                
                {history.length === 0 ? (
                  <p className="text-sm text-gray-500 dark:text-gray-400 pb-2 text-center py-4">{t("tools.abjad.noHistory")}</p>
                ) : (
                  <div className="space-y-3 max-h-[300px] overflow-y-auto pr-2">
                    {history.map(item => (
                      <div key={item.id} className="bg-gray-50 dark:bg-gray-900/50 p-4 rounded-2xl border border-gray-100 dark:border-gray-700 flex flex-col gap-3">
                        <div className="text-right font-arabic text-xl font-medium text-gray-900 dark:text-white" dir="rtl">{item.text}</div>
                        <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 sm:items-center justify-between border-t border-gray-200 dark:border-gray-700 pt-3">
                          <span className="text-xs text-gray-500 dark:text-gray-400 font-medium">{new Date(item.timestamp).toLocaleString()}</span>
                          <div className="flex gap-4">
                            <div className="flex flex-col items-center">
                              <span className="text-[10px] text-gray-400 uppercase tracking-wider">Mashriq</span>
                              <span className="text-blue-600 dark:text-blue-400 font-bold text-sm sm:text-base">{item.mashriqi}</span>
                            </div>
                            <div className="w-px bg-gray-200 dark:bg-gray-700"></div>
                            <div className="flex flex-col items-center">
                              <span className="text-[10px] text-gray-400 uppercase tracking-wider">Maghribi</span>
                              <span className="text-emerald-600 dark:text-emerald-400 font-bold text-sm sm:text-base">{item.maghribi}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Abjad Info Modal */}
      <AnimatePresence>
        {showAbjadInfoModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.5 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowAbjadInfoModal(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-gray-800 rounded-3xl p-6 shadow-2xl max-w-md w-full relative border border-gray-100 dark:border-gray-700 z-10 max-h-[90vh] overflow-y-auto"
            >
              <button
                onClick={() => setShowAbjadInfoModal(false)}
                className="absolute top-4 right-4 p-1.5 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-400 hover:text-gray-600 transition-colors cursor-pointer"
              >
                <X size={20} />
              </button>
              
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2.5 bg-blue-500/10 text-blue-500 rounded-xl">
                  <Calculator size={22} />
                </div>
                <h3 className="text-lg font-bold text-gray-900 dark:text-white">
                  Comment interpréter l'Abjad ?
                </h3>
              </div>
              
              <div className="space-y-4 text-sm text-gray-600 dark:text-gray-300">
                <p>
                  L'Abjad est un système d'écriture et de numérologie sacrée qui attribue une valeur numérique (adad) à chacune des 28 lettres de l'alphabet arabe.
                </p>
                <p>
                  <strong>Pour vos invocations et zikrs :</strong>
                  <br />
                  Le chiffre obtenu (par exemple, de votre prénom) représente votre <strong>résonance mystique</strong>. Vous pouvez utiliser ce chiffre comme nombre de répétitions quotidiennes pour un Nom Divin compatible (dont la valeur Abjad correspond à la vôtre).
                </p>
                <div className="bg-gray-50 dark:bg-gray-900 p-3 rounded-2xl border border-gray-100 dark:border-gray-700/50 space-y-2">
                  <p className="text-xs font-semibold text-gray-800 dark:text-gray-200">Différence entre les systèmes :</p>
                  <ul className="list-disc list-inside space-y-1 text-xs text-gray-500 dark:text-gray-400">
                    <li><strong>Mashriqi (Orientale) :</strong> Système standard traditionnel le plus répandu au Moyen-Orient.</li>
                    <li><strong>Maghribi (Occidentale) :</strong> Système privilégié en Afrique du Nord et de l'Ouest (traditions de l'Asrar ouest-africain et marocain).</li>
                  </ul>
                </div>
              </div>
              
              <button
                onClick={() => setShowAbjadInfoModal(false)}
                className="mt-6 w-full py-3 bg-blue-500 hover:bg-blue-600 text-white rounded-xl text-sm font-semibold transition-colors shadow-sm cursor-pointer"
              >
                J'ai compris
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
