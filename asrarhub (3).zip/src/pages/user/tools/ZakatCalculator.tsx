import React, { useState, useEffect } from 'react';
import { Coins, ArrowLeft, RefreshCw, Info, Database, Wifi } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useLanguage } from '../../../contexts/LanguageContext';
import { motion, AnimatePresence } from 'motion/react';
import { Haptics, ImpactStyle } from '@capacitor/haptics';

export const ZakatCalculator: React.FC = () => {
  const { t } = useLanguage();
  const [gold, setGold] = useState('');
  const [silver, setSilver] = useState('');
  const [cash, setCash] = useState('');
  const [stocks, setStocks] = useState('');
  const [merchandise, setMerchandise] = useState('');
  const [debts, setDebts] = useState('');

  const [goldPrice, setGoldPrice] = useState(65); // EUR per gram (approx)
  const [silverPrice, setSilverPrice] = useState(0.70); // EUR per gram (approx)
  const [isUsingCache, setIsUsingCache] = useState(true);

  // Load saved inputs from localStorage on mount
  useEffect(() => {
    try {
      const saved = localStorage.getItem('asrar_zakat_inputs');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.gold !== undefined) setGold(parsed.gold);
        if (parsed.silver !== undefined) setSilver(parsed.silver);
        if (parsed.cash !== undefined) setCash(parsed.cash);
        if (parsed.stocks !== undefined) setStocks(parsed.stocks);
        if (parsed.merchandise !== undefined) setMerchandise(parsed.merchandise);
        if (parsed.debts !== undefined) setDebts(parsed.debts);
      }
    } catch (e) {
      console.warn("Failed to load Zakat inputs from cache", e);
    }
  }, []);

  // Save inputs to localStorage when they change
  useEffect(() => {
    try {
      const data = { gold, silver, cash, stocks, merchandise, debts };
      localStorage.setItem('asrar_zakat_inputs', JSON.stringify(data));
    } catch (e) {
      console.warn("Failed to save Zakat inputs to cache", e);
    }
  }, [gold, silver, cash, stocks, merchandise, debts]);

  // Fetch current live Gold and Silver prices
  useEffect(() => {
    const fetchPrices = async () => {
      try {
        const savedPrices = localStorage.getItem('asrar_zakat_prices');
        if (savedPrices) {
          const { goldP, silverP } = JSON.parse(savedPrices);
          if (goldP) setGoldPrice(goldP);
          if (silverP) setSilverPrice(silverP);
        }

        if (!navigator.onLine) {
          setIsUsingCache(true);
          return;
        }

        // Fetch PAXG price (1 PAXG = 1 troy ounce of gold) from CoinGecko
        const res = await fetch('https://api.coingecko.com/api/v3/simple/price?ids=pax-gold&vs_currencies=eur');
        if (res.ok) {
          const data = await res.json();
          const paxgEur = data['pax-gold']?.eur;
          if (paxgEur) {
            const calculatedGoldPrice = Math.round((paxgEur / 31.1034768) * 100) / 100; // EUR per gram
            const calculatedSilverPrice = Math.round((calculatedGoldPrice / 80) * 100) / 100; // silver ratio
            setGoldPrice(calculatedGoldPrice);
            setSilverPrice(calculatedSilverPrice);
            setIsUsingCache(false);
            localStorage.setItem('asrar_zakat_prices', JSON.stringify({ goldP: calculatedGoldPrice, silverP: calculatedSilverPrice }));
          } else {
            setIsUsingCache(true);
          }
        } else {
          setIsUsingCache(true);
        }
      } catch (e) {
        setIsUsingCache(true);
      }
    };
    fetchPrices();
  }, []);

  const handleReset = async () => {
    setGold('');
    setSilver('');
    setCash('');
    setStocks('');
    setMerchandise('');
    setDebts('');
    try {
      await Haptics.impact({ style: ImpactStyle.Light });
    } catch (e) {
      if (navigator.vibrate) navigator.vibrate(40);
    }
  };

  // Nisab is either 85g of gold or 595g of silver
  const nisabGoldValue = 85 * goldPrice;
  const nisabSilverValue = 595 * silverPrice;

  // Use Gold or Silver Nisab? Many scholars today say use the lowest for benefit of the poor (Silver),
  // but gold is also widely used. Let's use Gold Nisab as default indicator, but show both.
  const nisab = nisabGoldValue; 

  const calculateTotal = () => {
    const goldVal = (parseFloat(gold) || 0) * goldPrice;
    const silverVal = (parseFloat(silver) || 0) * silverPrice;
    const cashVal = parseFloat(cash) || 0;
    const stocksVal = parseFloat(stocks) || 0;
    const merchVal = parseFloat(merchandise) || 0;
    const fixedDebts = parseFloat(debts) || 0;

    const totalAssets = goldVal + silverVal + cashVal + stocksVal + merchVal;
    const zakatableWealth = totalAssets - fixedDebts;
    
    return zakatableWealth > 0 ? zakatableWealth : 0;
  };

  const total = calculateTotal();
  const zakatDue = total >= nisab ? total * 0.025 : 0;

  return (
    <div className="max-w-3xl mx-auto p-4 sm:p-6 lg:p-8 safe-area-pt pb-24 min-h-screen">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-4">
          <Link 
            to="/tools" 
            className="p-2 -ml-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-500 transition-colors"
          >
            <ArrowLeft size={24} />
          </Link>
          <div>
            <h1 className="text-xl sm:text-2xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
              <Coins className="text-amber-500" />
              {t('tools.zakat.title', 'Calculateur de Zakat')}
            </h1>
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">{t('tools.zakat.description', 'Calculez précisément votre Zakat al-Maal (2.5%)')}</p>
            {isUsingCache ? (
              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-50 text-amber-700 dark:bg-amber-950/30 dark:text-amber-400 border border-amber-100 dark:border-amber-900/30 mt-2">
                <Database size={11} className="animate-pulse" />
                <span>Cache local (Mode Offline actif)</span>
              </div>
            ) : (
              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 dark:bg-emerald-950/30 dark:text-emerald-400 border border-emerald-100 dark:border-emerald-900/30 mt-2">
                <Wifi size={11} />
                <span>Prix de l'or en temps réel (PAXG)</span>
              </div>
            )}
          </div>
        </div>
        <button 
          onClick={handleReset}
          className="p-2 text-gray-500 hover:text-amber-600 hover:bg-amber-50 dark:hover:bg-amber-900/30 rounded-xl transition-colors"
          title={t('common.reset', 'Réinitialiser')}
        >
          <RefreshCw size={20} />
        </button>
      </div>

      <div className="bg-amber-50 dark:bg-amber-900/10 border border-amber-100 dark:border-amber-800/50 rounded-2xl p-5 mb-8 flex items-start gap-4">
        <Info className="text-amber-500 shrink-0 mt-0.5" size={24} />
        <div className="text-sm text-amber-800 dark:text-amber-200">
          <p className="font-bold mb-1">{t('tools.zakat.nissabRef', 'Le Nisab actuel (Seuil de richesse)')}</p>
          <p className="mb-2">{t('tools.zakat.nissabInfo', 'La Zakat est obligatoire si votre richesse nette atteint ou dépasse le Nisab pendant une année lunaire (Hawl).')}</p>
          <div className="grid grid-cols-2 gap-4 mt-3">
             <div className="bg-amber-100/50 dark:bg-amber-900/30 p-2 rounded-lg text-center">
                <span className="block text-xs uppercase opacity-70 font-bold">Base Or (85g)</span>
                <span className="font-mono font-bold">{nisabGoldValue.toLocaleString('fr-FR', {style: 'currency', currency: 'EUR'})}</span>
             </div>
             <div className="bg-amber-100/50 dark:bg-amber-900/30 p-2 rounded-lg text-center">
                <span className="block text-xs uppercase opacity-70 font-bold">Base Argent (595g)</span>
                <span className="font-mono font-bold">{nisabSilverValue.toLocaleString('fr-FR', {style: 'currency', currency: 'EUR'})}</span>
             </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <div className="bg-white dark:bg-gray-800 rounded-3xl p-5 shadow-sm border border-gray-100 dark:border-gray-700">
            <h3 className="font-bold text-gray-900 dark:text-white mb-4">1. Argent & Or</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-gray-500 mb-1">Or (en grammes)</label>
                <input type="number" value={gold} onChange={(e) => setGold(e.target.value)} placeholder="0" className="w-full bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl p-3 text-gray-900 dark:text-white" />
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-500 mb-1">Argent (en grammes)</label>
                <input type="number" value={silver} onChange={(e) => setSilver(e.target.value)} placeholder="0" className="w-full bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl p-3 text-gray-900 dark:text-white" />
              </div>
            </div>
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-3xl p-5 shadow-sm border border-gray-100 dark:border-gray-700">
            <h3 className="font-bold text-gray-900 dark:text-white mb-4">2. Liquidités & Comptes</h3>
            <div>
              <label className="block text-xs font-bold text-gray-500 mb-1">Argent liquide & Banque (EUR)</label>
              <input type="number" value={cash} onChange={(e) => setCash(e.target.value)} placeholder="0.00" className="w-full bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl p-3 text-gray-900 dark:text-white" />
            </div>
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-3xl p-5 shadow-sm border border-gray-100 dark:border-gray-700">
            <h3 className="font-bold text-gray-900 dark:text-white mb-4">3. Investissements & Commerce</h3>
             <div className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-gray-500 mb-1">Actions & Placements (EUR)</label>
                <input type="number" value={stocks} onChange={(e) => setStocks(e.target.value)} placeholder="0.00" className="w-full bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl p-3 text-gray-900 dark:text-white" />
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-500 mb-1">Marchandises destinées à la vente (EUR)</label>
                <input type="number" value={merchandise} onChange={(e) => setMerchandise(e.target.value)} placeholder="0.00" className="w-full bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl p-3 text-gray-900 dark:text-white" />
              </div>
            </div>
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-3xl p-5 shadow-sm border border-gray-100 dark:border-gray-700">
            <h3 className="font-bold text-red-500 mb-4">4. Dettes & Emprunts</h3>
             <div>
              <label className="block text-xs font-bold text-gray-500 mb-1">Dettes à rembourser immédiatement (EUR)</label>
              <input type="number" value={debts} onChange={(e) => setDebts(e.target.value)} placeholder="0.00" className="w-full bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl p-3 text-gray-900 dark:text-white" />
            </div>
          </div>
        </div>

        <div>
          <motion.div 
            className="bg-amber-500 rounded-3xl p-8 shadow-xl text-white sticky top-24"
            animate={{ scale: zakatDue > 0 ? 1.02 : 1 }}
            transition={{ type: "spring", stiffness: 300 }}
          >
            <h3 className="uppercase tracking-widest text-xs font-bold mb-6 text-amber-100">{t('tools.zakat.resultsTitle', 'Bilan Zakat')}</h3>
            
            <div className="space-y-3 mb-8">
               <div className="flex justify-between items-center text-sm border-b border-amber-400/30 pb-2">
                 <span>{t('tools.zakat.totalAssets', 'Richesse totale estimée')}</span>
                 <span className="font-mono">{total.toLocaleString('fr-FR', {style: 'currency', currency: 'EUR'})}</span>
               </div>
               <div className="flex justify-between items-center text-sm border-b border-amber-400/30 pb-2 text-amber-200">
                 <span>{t('tools.zakat.nissabRef', 'Nisab (Base Or)')}</span>
                 <span className="font-mono">{nisab.toLocaleString('fr-FR', {style: 'currency', currency: 'EUR'})}</span>
               </div>
            </div>

            <div className="bg-amber-600/50 rounded-2xl p-6 text-center shadow-inner">
               <span className="block text-amber-200 text-sm font-bold uppercase tracking-widest mb-2">{t('tools.zakat.zakatDue', 'Montant de Zakat dû')}</span>
               <span className="block text-4xl sm:text-5xl font-black tabular-nums tracking-tight">
                 {zakatDue.toLocaleString('fr-FR', {style: 'currency', currency: 'EUR'})}
               </span>
            </div>

            {total > 0 && total < nisab && (
              <p className="text-center mt-6 text-sm font-medium bg-white/20 p-3 rounded-xl border border-white/30">
                {t('tools.zakat.notEligible', 'Votre richesse n\'a pas atteint le Nisab. La Zakat n\'est pas obligatoire.')}
              </p>
            )}

            {zakatDue > 0 && (
              <p className="text-center mt-6 text-sm font-medium bg-black/20 p-3 rounded-xl border border-black/10">
                Alhamdulillah, la purification de vos biens s'élève à 2.5% de votre richesse nette. Pensez à la reverser aux nécessiteux.
              </p>
            )}
          </motion.div>
        </div>
      </div>
    </div>
  );
};
